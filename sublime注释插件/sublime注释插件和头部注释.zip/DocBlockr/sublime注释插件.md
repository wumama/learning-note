## sublime Text3 注释插件

### 介绍

sublime Text3 注释插件——DocBlockr

简介：标准的注释，包括函数名、参数、返回值等，并以多行显示，省去手动编写。

链接：

- https://github.com/spadgos/sublime-jsdocs
- https://packagecontrol.io/packages/DocBlockr
- http://usejsdoc.org/

### 安装

1. 第一步：给sublime Text3 安装Package Control（安装了的自动忽略这一步）

   - 使用Ctrl+`快捷键或者通过View->Show Console菜单打开命令行，粘贴如下代码：

   ```javascript
   import urllib.request,os; pf = 'Package Control.sublime-package'; ipp = sublime.installed_packages_path(); urllib.request.install_opener( urllib.request.build_opener( urllib.request.ProxyHandler()) ); open(os.path.join(ipp, pf), 'wb').write(urllib.request.urlopen( 'http://sublime.wbond.net/' + pf.replace(' ','%20')).read())
   ```

   如果顺利的话，此时就可以在Preferences菜单下看到Package Settings和Package Control两个菜单了。

   - 由于各种扯蛋的原因，无法使用代码安装，那可以通过以下步骤手动安装：
     - 点击Preferences *>* Browse Packages菜单
     - 进入打开的目录的上层目录，然后再进入Installed Packages/目录
     - 下载[Package Control.sublime-package](https://sublime.wbond.net/Package%20Control.sublime-package)并复制到Installed Packages/目录
     - 重启Sublime Text。

2. 第二步：打开sublime Text3 安装DocBlockr插件

   - 按下Ctrl+shift+p 调出命令面板
   - 输入install 调出Install Package 选项并回车，然后在列表中选中DocBlockr插件。

   有时候网速可能会影响，途中出现的各种问题，自己百度解决。嘿嘿。

3. 第三步：配置DocBlockr

   - 打开Preferences -> Package Settings -> DocBlockr->Settings - User把DocBlockr.json里面的代码复制到里面
   - 保存文件即可

### 使用

- 快速注释：输入 /* 或者 /** 然后按Enter

- 函数注释：在函数前面一行输入/**  按Enter，使用Tab可以在不同字段切换。  例如：

  ```javascript
  /**
  function test(){}
  ```

- 变量注释：和函数注释一样。PS：如果想让注释在一行显示完输入/** 后按shift+Enter

注意：

```javascript
/**
 * 这里的注释内容【会】被压缩工具压缩
 */
 
/*！
 * 这里的注释内容【不会】被压缩工具压缩
 * 与上面一个注释块不同的是，第2个*换成了!
 */
```



## sublime 头部注释

- 把addinfo.py（自动生成头部注释）和addCurrentTime.py（更新日期）文件放在Tools->Developer->New Plugin下

- 新建的文件名和addinfo.py和addCurrentTime.py文件名一致

- 在Preferences->Key Bindings-User里设置快捷键

  ```javascript
  [
      {
          "command": "add_info",
          "keys": [
              "ctrl+shift+,"
          ]
      },
      {
          "command": "add_current_time",
          "keys": [
              "ctrl+shift+."
          ]
      }

  ]
  ```

- 重启sublime